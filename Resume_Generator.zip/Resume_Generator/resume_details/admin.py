from django.contrib import admin

# Register your models here.
from .models import Resume_Detail

admin.site.register(Resume_Detail)
